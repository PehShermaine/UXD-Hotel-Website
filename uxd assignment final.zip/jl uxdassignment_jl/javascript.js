
  // When the user scrolls the page, execute myFunction
  window.onscroll = function() {myFunction()};

  // Get the topbar
  var topbar = document.getElementById("topbar");

  // Get the offset position of the topbar
  var sticky = topbar.offsetTop;

  // Add the sticky class to the topbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
  function myFunction() {
  if (window.pageYOffset >= sticky) {
    topbar.classList.add("sticky")
  } else {
    topbar.classList.remove("sticky");
  }
  }


// validate booking form
function validateForm() {

  var checkin = document.getElementById('checkin').value;
  var checkout = document.getElementById('checkout').value;
  var roomsno = document.getElementById('roomsno').value;
  var adultsno = document.getElementById('adultsno').value;
  var childno = document.getElementById('childno').value;
  //var specialrate = document.getElementById('ratesinput').value;

  window.localStorage.setItem('checkindate', checkin);
  window.localStorage.setItem('checkoutdate', checkout);
  window.localStorage.setItem('numroom', roomsno);
  window.localStorage.setItem('adult', adultsno);
  window.localStorage.setItem('child', childno);
  //window.localStorage.setItem('special', specialrate);


    if (checkin > checkout) {
      alert('Invalid check-out date.');
      return false;
    }

    if (roomsno <= 0) {
      alert('Please enter number of rooms.');
      return false;
    }

    if (adultsno == 0 || childno == null || childno == '') {
      alert('Please enter number of adults / children.');
      return false;
    }
}


// display input on rates page
function ratedisplay() {

const opendate = window.localStorage.getItem('checkindate');
const closedate = window.localStorage.getItem('checkoutdate');
const numroom = window.localStorage.getItem('numroom');
const adult = window.localStorage.getItem('adult');
const child = window.localStorage.getItem('child');
//const child = window.localStorage.getItem('special');


document.getElementById('replacecheckin').innerHTML = opendate;
document.getElementById('replacecheckout').innerHTML = closedate;

//if (special == 'N/A') {
  if (child == 0) {
    document.getElementById('replacerandg').innerHTML = numroom +  ' Room(s) and '+ adult + ' Adult(s)';
  }
  else if (child == 1) {
    document.getElementById('replacerandg').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Child';
  }

  else if (child > 1) {
    document.getElementById('replacerandg').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Children';
  }
//}

//else {
  if (child == 0) {
    document.getElementById('replacerandg').innerHTML = numroom +  ' Room(s) and '+ adult + ' Adult(s)';// + ' (' + special ')';
  }
  else if (child == 1) {
    document.getElementById('replacerandg').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Child';// + ' (' + special ')';
  }

  else if (child > 1) {
    document.getElementById('replacerandg').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Children';// + ' (' + special ')';
  }
//}

}


// display input on information form
function informationbox() {

const opendate = window.localStorage.getItem('checkindate');
const closedate = window.localStorage.getItem('checkoutdate');
const numroom = window.localStorage.getItem('numroom');
const adult = window.localStorage.getItem('adult');
const child = window.localStorage.getItem('child');


document.getElementById('infoduration').innerHTML = opendate + ' to ' + closedate;


if (child == 0) {
  document.getElementById('infoamount').innerHTML = numroom +  ' Room(s) and '+ adult + ' Adult(s)';
}
else if (child == 1) {
  document.getElementById('infoamount').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Child';
}

else if (child > 1) {
  document.getElementById('infoamount').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Children';
}
}


//validate information form
function validinfoform() {

var name = document.getElementById('names').value;
var phonenumber = document.getElementById('phonenumber').value;
var email = document.getElementById('emails').value;

window.localStorage.setItem('name', name);
window.localStorage.setItem('pnum', phonenumber);
window.localStorage.setItem('email', email);

if (name.length <= 0) {
          alert('Please enter a name.');
          return false;
        }

if (phonenumber == null || phonenumber == "") {
          alert('Please enter a phone number.');
          return false;
        }

if (email == null || email == "") {
          alert('Please enter an email.');
          return false;
        }
}


// comfirmation page
function comfirm() {
const opendate = window.localStorage.getItem('checkindate');
const closedate = window.localStorage.getItem('checkoutdate');
const numroom = window.localStorage.getItem('numroom');
const adult = window.localStorage.getItem('adult');
const child = window.localStorage.getItem('child');

const name = window.localStorage.getItem('name');
const pnum = window.localStorage.getItem('pnum');
const email = window.localStorage.getItem('email');


document.getElementById('thanksdata').innerHTML = 'Room booking for ' + name + ', ' + pnum + ', ' + email;
document.getElementById('days').innerHTML = 'Duration of stay: ' + opendate + ' to ' + closedate;

if (child == 0) {
document.getElementById('numberss').innerHTML = numroom +  ' Room(s) and '+ adult + ' Adult(s)';
}

else if (child == 1) {
document.getElementById('numberss').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Child' ;
}

else if (child > 1) {
document.getElementById('numberss').innerHTML = numroom + ' Room(s), '+ adult + ' Adult(s) and '+ child +' Children' ;
}


}
