const prevBtns = document.querySelectorAll(".btn-prev");
const nextBtns = document.querySelectorAll(".btn-next");
const progress = document.getElementById("progress");
const formSteps = document.querySelectorAll(".form-step");
const progressSteps = document.querySelectorAll(".progress-step");

let formStepsNum = 0;


nextBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    formStepsNum++;
    updateFormSteps();
    updateProgressbar();
  });
});

prevBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    formStepsNum--;
    updateFormSteps();
    updateProgressbar();
  });
});

function updateFormSteps(){

  formSteps.forEach(formStep => {
    formStep.classList.contains("form-step-active")&&
      formStep.classList.remove("form-step-active");
  });

  formSteps[formStepsNum].classList.add("form-step-active");
}

function updateProgressbar(){
  progressSteps.forEach((progressStep, idx) => {
    if (idx < formStepsNum + 1) {
      progressStep.classList.add('progress-step-active')
    } else {
      progressStep.classList.remove('progress-step-active')
    }
  });

  const progressActive = document.querySelectorAll(".progress-step-active");

  progress.style.width = ((progressActive.length - 1) / (progressSteps.length - 1) ) * 100 + "%" ;
}

// When the user scrolls the page, execute myFunction
window.onscroll = function() {myFunction()};

// Get the topbar
var topbar = document.getElementById("topbar");

// Get the offset position of the topbar
var sticky = topbar.offsetTop;

// Add the sticky class to the topbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
function myFunction() {
if (window.pageYOffset >= sticky) {
  topbar.classList.add("sticky")
} else {
  topbar.classList.remove("sticky");
}
}
